// تأكيد تحميل DOM بالكامل
document.addEventListener("DOMContentLoaded", function() {
  let currentUser = "";
  let currentMovie = null;
  let allArtists = [];
  
  // بيانات المسلسل الحالي
  let globalSeriesData = null;
  let selectedSeason = 1;
  let selectedEpisode = 0;
  let currentScroll = 0;
  
  // متغيرات لتخزين بيانات الأفلام والمسلسلات للبحث
  let globalMovies = [];
  let globalSeries = [];
  
  function clearModalFields(modalId) {
    const modal = document.getElementById(modalId);
    const inputs = modal.querySelectorAll('input, textarea, select');
    inputs.forEach(el => el.value = "");
    if(modalId === 'modalAddMovie'){
      document.getElementById('movieStarSuggestions').innerHTML = "";
      document.getElementById('movieStarList').innerHTML = "";
    }
    if(modalId === 'modalAddSeries'){
      document.getElementById('seriesStarSuggestions').innerHTML = "";
      document.getElementById('seriesStarList').innerHTML = "";
      document.getElementById('seasonsEpisodes').innerHTML = "";
    }
  }
  
  // التحقق من بيانات الجلسة
  fetch('/sessionUser')
    .then(response => response.json())
    .then(data => {
      if(data.username){
        currentUser = data.username;
        if(currentUser.toLowerCase() === "hassankuordish"){
          document.getElementById('plusContainer').style.setProperty('display', 'block', 'important');
        } else {
          document.getElementById('plusContainer').style.setProperty('display', 'none', 'important');
        }
      } else {
        window.location.href = "login.html";
      }
    })
    .catch(err => {
      console.error("خطأ أثناء جلب بيانات الجلسة:", err);
      window.location.href = "login.html";
    });
  
  // أزرار البار العلوي
  document.getElementById('btnLogout').addEventListener('click', () => {
    fetch('/logout', { method: 'POST' })
      .then(() => window.location.href = "login.html")
      .catch(err => console.error(err));
  });
  document.getElementById('btnProfile').addEventListener('click', () => {
    document.getElementById('modalProfile').style.display = 'flex';
  });
  document.getElementById('closeProfile').addEventListener('click', () => {
    document.getElementById('modalProfile').style.display = 'none';
    clearModalFields('modalProfile');
  });
  document.getElementById('submitProfile').addEventListener('click', () => {
    const updatedData = {
      firstName: document.getElementById('profileFirstName').value,
      lastName: document.getElementById('profileLastName').value,
      email: document.getElementById('profileEmail').value
    };
    fetch('/updateProfile', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(updatedData)
    })
    .then(response => response.json())
    .then(data => {
      if(data.success){
        alert("تم تحديث المعلومات");
        document.getElementById('modalProfile').style.display = 'none';
        clearModalFields('modalProfile');
      } else alert(data.message);
    })
    .catch(err => console.error(err));
  });
  
  // القائمة المنسدلة لزر "إضافة"
  const plusButton = document.getElementById('plusButton');
  const plusDropdown = document.getElementById('plusDropdown');
  plusButton.addEventListener('click', () => {
    plusDropdown.style.display = (plusDropdown.style.display === 'block') ? 'none' : 'block';
  });
  document.addEventListener('click', function(event) {
    if (!document.getElementById('plusContainer').contains(event.target)) {
      plusDropdown.style.display = 'none';
    }
  });
  
  // --- منطق شريط البحث (Autocomplete) ---
  // تأكد من وجود عنصرين في index.html: input بـ id="searchInput" وحاوية بـ id="searchSuggestions"
  const searchInput = document.getElementById('searchInput');
  const searchSuggestions = document.getElementById('searchSuggestions');
  
  searchInput.addEventListener('keyup', function() {
    const query = searchInput.value.trim().toLowerCase();
    searchSuggestions.innerHTML = "";
    if(query === "") {
      searchSuggestions.style.display = "none";
      return;
    }
    let results = [];
    globalMovies.forEach(movie => {
      if(movie.name.toLowerCase().includes(query)) {
        results.push({ type: "movie", data: movie });
      }
    });
    globalSeries.forEach(series => {
      if(series.name.toLowerCase().includes(query)) {
        results.push({ type: "series", data: series });
      }
    });
    if(results.length === 0) {
      searchSuggestions.style.display = "none";
      return;
    }
    results.forEach(item => {
      const div = document.createElement('div');
      div.className = "suggestion-item";
      div.innerText = item.data.name;
      div.addEventListener('click', function() {
        searchSuggestions.style.display = "none";
        searchInput.value = "";
        if(item.type === "movie") {
          showFilmDetail(item.data);
        } else if(item.type === "series") {
          showSeriesDetail(item.data);
        }
      });
      searchSuggestions.appendChild(div);
    });
    searchSuggestions.style.display = "block";
  });
  
  // دالة عرض تفاصيل الفيلم (للشريط البحث)
  function showFilmDetail(movie) {
    currentMovie = movie;
    document.getElementById('filmDetailImage').src = movie.cover;
    document.getElementById('filmDetailName').innerText = movie.name;
    document.getElementById('filmDetailYearRating').innerText =
      new Date(movie.releaseDate).getFullYear() + " - " + movie.rating;
    document.getElementById('filmDetailStory').innerText = movie.story;
    const actorsContainer = document.getElementById('filmActorsContainer');
    actorsContainer.innerHTML = "";
    if(movie.stars && movie.stars.length > 0) {
      movie.stars.forEach(starName => {
        let actorDiv = document.createElement('div');
        actorDiv.className = "actor-card";
        let matchedArtist = allArtists.find(a => a.name.toLowerCase() === starName.toLowerCase());
        if(matchedArtist) {
          actorDiv.innerHTML = `<img src="${matchedArtist.image}" alt="${matchedArtist.name}">
                                <span>${matchedArtist.name}</span>`;
        } else {
          actorDiv.innerHTML = `<img src="default_actor.png" alt="${starName}">
                                <span>${starName}</span>`;
        }
        actorsContainer.appendChild(actorDiv);
      });
    }
    document.getElementById('modalFilmDetail').style.display = 'flex';
  }
  
  // دالة عرض تفاصيل المسلسل (للشريط البحث)
  function showSeriesDetail(series) {
    globalSeriesData = series;
    selectedSeason = 1;
    selectedEpisode = 0;
    currentScroll = 0;
    
    document.getElementById('seriesDetailImage').src = series.image;
    document.getElementById('seriesDetailName').innerText = series.name;
    document.getElementById('seriesDetailYearRating').innerText =
      new Date(series.releaseDate).getFullYear() + " - " + series.rating;
    document.getElementById('seriesDetailStory').innerText = series.story;
    
    const actorsContainer = document.getElementById('seriesActorsContainer');
    actorsContainer.innerHTML = "";
    if(series.stars && series.stars.length > 0) {
      series.stars.forEach(starName => {
        let actorDiv = document.createElement('div');
        actorDiv.className = "actor-card";
        let matchedArtist = allArtists.find(a => a.name.toLowerCase() === starName.toLowerCase());
        if(matchedArtist) {
          actorDiv.innerHTML = `<img src="${matchedArtist.image}" alt="${matchedArtist.name}">
                                <span>${matchedArtist.name}</span>`;
        } else {
          actorDiv.innerHTML = `<img src="default_actor.png" alt="${starName}">
                                <span>${starName}</span>`;
        }
        actorsContainer.appendChild(actorDiv);
      });
    }
    
    const seasonSelect = document.getElementById('seasonSelect');
    seasonSelect.innerHTML = "";
    if(series.seasons) {
      Object.keys(series.seasons).forEach(seasonNum => {
        let option = document.createElement('option');
        option.value = seasonNum;
        option.textContent = "الموسم " + seasonNum;
        seasonSelect.appendChild(option);
      });
    }
    if(series.seasons && Object.keys(series.seasons).length > 0) {
      let firstSeason = Object.keys(series.seasons)[0];
      selectedSeason = firstSeason;
      seasonSelect.value = firstSeason;
      generateEpisodesUI(series, firstSeason);
    }
    
    document.getElementById('modalSeriesDetail').style.display = 'flex';
  }
  
  // تحميل بيانات الأفلام والمسلسلات من JSON (للبحث)
  fetch('/movies.json')
    .then(r => r.json())
    .then(movies => { globalMovies = movies; });
  fetch('/series.json')
    .then(r => r.json())
    .then(series => { globalSeries = series; });
  
  // باقي الكود كما هو دون تغيير
  
  // تحميل المحتوى حسب الفئة
  function loadHomeContent() {
    currentCategory = "home";
    const contentArea = document.getElementById('contentArea');
    contentArea.innerHTML = "<h3>الرئيسية</h3>";
    fetch('/getSections?category=home')
      .then(res => res.json())
      .then(sections => {
        let uniqueSections = [...new Set(sections)];
        uniqueSections.forEach(sectionName => {
          let sectionDiv = document.createElement('div');
          sectionDiv.className = "section-container";
          sectionDiv.innerHTML = `<h4>${sectionName}</h4>`;
          sectionDiv.innerHTML += `<div class="home-container">[عناصر ${sectionName} ستظهر هنا]</div>`;
          contentArea.appendChild(sectionDiv);
        });
      });
  }
  
  // تحميل بيانات artists.json
  fetch('/artists.json')
    .then(response => response.json())
    .then(data => {
      allArtists = data;
    });
  
  function loadMoviesContent() {
    currentCategory = "movies";
    const contentArea = document.getElementById('contentArea');
    contentArea.innerHTML = "<h3>الأفلام</h3>";
    fetch('/getSections?category=movies')
      .then(res => res.json())
      .then(sections => {
        let uniqueSections = [...new Set(sections)];
        uniqueSections.forEach(sectionName => {
          let sectionDiv = document.createElement('div');
          sectionDiv.className = "section-container";
          sectionDiv.innerHTML = `<h4>${sectionName}</h4>`;
          let moviesContainer = document.createElement('div');
          moviesContainer.className = "movies-container";
          fetch('/movies.json')
            .then(r => r.json())
            .then(movies => {
              let filtered = movies.filter(m => m.section === sectionName);
              filtered.forEach(movie => {
                let movieDiv = document.createElement('div');
                movieDiv.className = "movie-item";
                movieDiv.innerHTML = `
                  <img src="${movie.cover}" alt="${movie.name}"><br>
                  ${movie.name}<br>
                  ${movie.rating} - ${new Date(movie.releaseDate).getFullYear()}
                `;
                movieDiv.addEventListener('click', () => {
                  currentMovie = movie;
                  document.getElementById('filmDetailImage').src = movie.cover;
                  document.getElementById('filmDetailName').innerText = movie.name;
                  document.getElementById('filmDetailYearRating').innerText =
                    new Date(movie.releaseDate).getFullYear() + " - " + movie.rating;
                  document.getElementById('filmDetailStory').innerText = movie.story;
                  const actorsContainer = document.getElementById('filmActorsContainer');
                  actorsContainer.innerHTML = "";
                  if (movie.stars && movie.stars.length > 0) {
                    movie.stars.forEach(starName => {
                      let actorDiv = document.createElement('div');
                      actorDiv.className = "actor-card";
                      let matchedArtist = allArtists.find(a => a.name.toLowerCase() === starName.toLowerCase());
                      if (matchedArtist) {
                        actorDiv.innerHTML = `<img src="${matchedArtist.image}" alt="${matchedArtist.name}">
                                              <span>${matchedArtist.name}</span>`;
                      } else {
                        actorDiv.innerHTML = `<img src="default_actor.png" alt="${starName}">
                                              <span>${starName}</span>`;
                      }
                      actorsContainer.appendChild(actorDiv);
                    });
                  }
                  document.getElementById('modalFilmDetail').style.display = 'flex';
                });
                moviesContainer.appendChild(movieDiv);
              });
            });
          sectionDiv.appendChild(moviesContainer);
          contentArea.appendChild(sectionDiv);
        });
      });
  }
  
  function loadSeriesContent() {
    currentCategory = "series";
    const contentArea = document.getElementById('contentArea');
    contentArea.innerHTML = "<h3>المسلسلات</h3>";
    fetch('/getSections?category=series')
      .then(res => res.json())
      .then(sections => {
        let uniqueSections = [...new Set(sections)];
        uniqueSections.forEach(sectionName => {
          let sectionDiv = document.createElement('div');
          sectionDiv.className = "section-container";
          sectionDiv.innerHTML = `<h4>${sectionName}</h4>`;
          let seriesContainer = document.createElement('div');
          seriesContainer.className = "series-container";
          fetch('/series.json')
            .then(r => r.json())
            .then(seriesList => {
              let filtered = seriesList.filter(s => s.section === sectionName);
              filtered.forEach(series => {
                let seriesDiv = document.createElement('div');
                seriesDiv.className = "series-item";
                seriesDiv.innerHTML = `
                  <img src="${series.image}" alt="${series.name}"><br>
                  ${series.name}<br>
                  ${series.rating} - ${new Date(series.releaseDate).getFullYear()}
                `;
                seriesDiv.addEventListener('click', () => {
                  globalSeriesData = series;
                  selectedSeason = 1;
                  selectedEpisode = 0;
                  currentScroll = 0;
                  
                  document.getElementById('seriesDetailImage').src = series.image;
                  document.getElementById('seriesDetailName').innerText = series.name;
                  document.getElementById('seriesDetailYearRating').innerText =
                    new Date(series.releaseDate).getFullYear() + " - " + series.rating;
                  document.getElementById('seriesDetailStory').innerText = series.story;
                  
                  const actorsContainer = document.getElementById('seriesActorsContainer');
                  actorsContainer.innerHTML = "";
                  if (series.stars && series.stars.length > 0) {
                    series.stars.forEach(starName => {
                      let actorDiv = document.createElement('div');
                      actorDiv.className = "actor-card";
                      let matchedArtist = allArtists.find(a => a.name.toLowerCase() === starName.toLowerCase());
                      if (matchedArtist) {
                        actorDiv.innerHTML = `<img src="${matchedArtist.image}" alt="${matchedArtist.name}">
                                              <span>${matchedArtist.name}</span>`;
                      } else {
                        actorDiv.innerHTML = `<img src="default_actor.png" alt="${starName}">
                                              <span>${starName}</span>`;
                      }
                      actorsContainer.appendChild(actorDiv);
                    });
                  }
                  
                  const seasonSelect = document.getElementById('seasonSelect');
                  seasonSelect.innerHTML = "";
                  if (series.seasons) {
                    Object.keys(series.seasons).forEach(seasonNum => {
                      let option = document.createElement('option');
                      option.value = seasonNum;
                      option.textContent = "الموسم " + seasonNum;
                      seasonSelect.appendChild(option);
                    });
                  }
                  if (series.seasons && Object.keys(series.seasons).length > 0) {
                    let firstSeason = Object.keys(series.seasons)[0];
                    selectedSeason = firstSeason;
                    seasonSelect.value = firstSeason;
                    generateEpisodesUI(series, firstSeason);
                  }
                  
                  document.getElementById('modalSeriesDetail').style.display = 'flex';
                });
                seriesContainer.appendChild(seriesDiv);
              });
            });
          sectionDiv.appendChild(seriesContainer);
          contentArea.appendChild(sectionDiv);
        });
      });
  }
  
  // عند تغيير الموسم من القائمة المنسدلة في نافذة تفاصيل المسلسل
  const seasonSelectElem = document.getElementById('seasonSelect');
  seasonSelectElem.addEventListener('change', () => {
    selectedSeason = seasonSelectElem.value;
    if (globalSeriesData) {
      generateEpisodesUI(globalSeriesData, selectedSeason);
    }
  });
  
  // دالة توليد واجهة الحلقات للموسم المختار
  function generateEpisodesUI(seriesData, seasonNumber) {
    const episodesWrapper = document.getElementById('episodesWrapper');
    episodesWrapper.innerHTML = "";
    currentScroll = 0;
    episodesWrapper.style.transform = `translateX(0px)`;
    
    if (!seriesData.seasons || !seriesData.seasons[seasonNumber]) return;
    let seasonData = seriesData.seasons[seasonNumber];
    let numEpisodes = seasonData.numberOfEpisodes;
    let links = seasonData.links;
    
    for (let i = 0; i < numEpisodes; i++) {
      let episodeDiv = document.createElement('div');
      episodeDiv.className = "episode-item";
      episodeDiv.innerHTML = `
        <img src="${seriesData.image}" alt="الحلقة ${i+1}">
        <span>الحلقة ${i+1}</span>
      `;
      episodeDiv.addEventListener('click', () => {
        selectedEpisode = i;
        document.querySelectorAll('.episode-item').forEach(item => item.classList.remove('active'));
        episodeDiv.classList.add('active');
      });
      episodesWrapper.appendChild(episodeDiv);
    }
  }
  
  // دالتي التمرير يمين/يسار للحلقات
  function scrollEpisodes(delta) {
    const episodesWrapper = document.getElementById('episodesWrapper');
    currentScroll += delta;
    if (currentScroll < 0) currentScroll = 0;
    let maxScroll = episodesWrapper.scrollWidth - episodesWrapper.clientWidth;
    if (currentScroll > maxScroll) currentScroll = maxScroll;
    episodesWrapper.style.transform = `translateX(${-currentScroll}px)`;
  }
  
  document.getElementById('scrollLeftBtn').addEventListener('click', () => {
    scrollEpisodes(-200);
  });
  document.getElementById('scrollRightBtn').addEventListener('click', () => {
    scrollEpisodes(200);
  });
  
  // زر تشغيل المسلسل
  document.getElementById('playSeriesBtn').addEventListener('click', () => {
    if (!globalSeriesData || !globalSeriesData.seasons) return;
    let seasonData = globalSeriesData.seasons[selectedSeason];
    if (!seasonData) return;
    let chosenLink = seasonData.links[selectedEpisode];
    let seriesPlaybackData = {
      seriesName: globalSeriesData.name,
      seasonNumber: selectedSeason,
      episodeIndex: selectedEpisode,
      episodeLink: chosenLink
    };
    localStorage.setItem('currentSeries', JSON.stringify(seriesPlaybackData));
    window.location.href = "series_playback_board.html";
  });
  
  // زر إغلاق نافذة تفاصيل المسلسل
  document.getElementById('closeSeriesDetail').addEventListener('click', () => {
    document.getElementById('modalSeriesDetail').style.display = 'none';
  });
  
  // إغلاق نافذة تفاصيل الفيلم
  document.getElementById('closeFilmDetail').addEventListener('click', () => {
    document.getElementById('modalFilmDetail').style.display = 'none';
  });
  
  // زر تشغيل الفيلم
  document.getElementById('playFilmBtn').addEventListener('click', () => {
    localStorage.setItem('currentMovie', JSON.stringify(currentMovie));
    window.location.href = "movie_playback_board.html";
  });
  
  // إعداد النوافذ المنبثقة لإضافة البيانات
  let currentSectionCategory = "";
  document.querySelectorAll('.add-section').forEach(item => {
    item.addEventListener('click', function(){
      currentSectionCategory = this.getAttribute('data-category');
      document.getElementById('modalAddSection').style.display = 'flex';
    });
  });
  document.getElementById('closeAddSection').addEventListener('click', () => {
    document.getElementById('modalAddSection').style.display = 'none';
    clearModalFields('modalAddSection');
  });
  document.getElementById('submitAddSection').addEventListener('click', () => {
    const sectionName = document.getElementById('sectionNameInput').value;
    if(!sectionName){
      alert("ادخل اسم القسم");
      return;
    }
    fetch('/addSection', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ category: currentSectionCategory, sectionName: sectionName })
    })
    .then(response => response.json())
    .then(data => {
      if(data.success){
        alert("تم إضافة القسم");
        document.getElementById('modalAddSection').style.display = 'none';
        clearModalFields('modalAddSection');
      } else {
        alert(data.message);
      }
    })
    .catch(err => {
      console.error(err);
      alert("حدث خطأ");
    });
  });
  
  document.getElementById('addArtistOption').addEventListener('click', () => {
    document.getElementById('modalAddArtist').style.display = 'flex';
  });
  document.getElementById('closeAddArtist').addEventListener('click', () => {
    document.getElementById('modalAddArtist').style.display = 'none';
    clearModalFields('modalAddArtist');
  });
  document.getElementById('submitAddArtist').addEventListener('click', () => {
    const name = document.getElementById('artistName').value;
    const image = document.getElementById('artistImage').value;
    const nationality = document.getElementById('artistNationality').value;
    if(!name || !image || !nationality){
      alert("يرجى ملء جميع الحقول");
      return;
    }
    fetch('/addArtist', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, image, nationality })
    })
    .then(response => response.json())
    .then(data => {
      if(data.success){
        alert("تم إضافة الفنان");
        document.getElementById('modalAddArtist').style.display = 'none';
        clearModalFields('modalAddArtist');
      } else {
        alert(data.message);
      }
    })
    .catch(err => {
      console.error(err);
      alert("حدث خطأ");
    });
  });
  
  document.getElementById('addMovieOption').addEventListener('click', () => {
    fetch('/getSections?category=movies')
      .then(response => response.json())
      .then(data => {
        const select = document.getElementById('movieSectionSelect');
        select.innerHTML = "";
        data.forEach(section => {
          let option = document.createElement('option');
          option.value = section;
          option.textContent = section;
          select.appendChild(option);
        });
        document.getElementById('modalAddMovie').style.display = 'flex';
      });
  });
  document.getElementById('closeAddMovie').addEventListener('click', () => {
    document.getElementById('modalAddMovie').style.display = 'none';
    clearModalFields('modalAddMovie');
  });
  document.getElementById('submitAddMovie').addEventListener('click', () => {
    let selectedArtists = [];
    document.querySelectorAll('#movieStarList .selected-artist').forEach(item => {
      selectedArtists.push(item.dataset.artist);
    });
    const movieData = {
      name: document.getElementById('movieName').value,
      releaseDate: document.getElementById('movieReleaseDate').value,
      section: document.getElementById('movieSectionSelect').value,
      story: document.getElementById('movieStory').value,
      rating: document.getElementById('movieRating').value,
      cover: document.getElementById('movieCover').value,
      link: document.getElementById('movieLink').value,
      language: document.getElementById('movieLanguage').value,
      country: document.getElementById('movieCountry').value,
      stars: selectedArtists
    };
    fetch('/addMovie', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(movieData)
    })
    .then(response => response.json())
    .then(data => {
      if(data.success){
        alert("تم إضافة الفيلم");
        document.getElementById('modalAddMovie').style.display = 'none';
        clearModalFields('modalAddMovie');
        if(currentCategory === "movies") loadMoviesContent();
      } else {
        alert(data.message);
      }
    })
    .catch(err => {
      console.error(err);
      alert("حدث خطأ");
    });
  });
  
  document.getElementById('addSeriesOption').addEventListener('click', () => {
    fetch('/getSections?category=series')
      .then(response => response.json())
      .then(data => {
        const select = document.getElementById('seriesSectionSelect');
        select.innerHTML = "";
        data.forEach(section => {
          let option = document.createElement('option');
          option.value = section;
          option.textContent = section;
          select.appendChild(option);
        });
        document.getElementById('modalAddSeries').style.display = 'flex';
      });
  });
  document.getElementById('closeAddSeries').addEventListener('click', () => {
    document.getElementById('modalAddSeries').style.display = 'none';
    clearModalFields('modalAddSeries');
  });
  document.getElementById('seriesSeasons').addEventListener('input', function(){
    const numSeasons = parseInt(this.value);
    const container = document.getElementById('seasonsEpisodes');
    container.innerHTML = "";
    for(let i = 1; i <= numSeasons; i++){
      const seasonDiv = document.createElement('div');
      seasonDiv.innerHTML = `<label>الموسم ${i}: اكتب عدد حلقات</label>
        <input type="number" data-season="${i}" class="episodesCount" placeholder="عدد حلقات الموسم ${i}">
        <div class="episodes-links" id="episodesLinks_${i}"></div>`;
      container.appendChild(seasonDiv);
      seasonDiv.querySelector('.episodesCount').addEventListener('change', function(){
        const seasonNum = this.dataset.season;
        const episodesContainer = document.getElementById('episodesLinks_' + seasonNum);
        episodesContainer.innerHTML = "";
        const numEpisodes = parseInt(this.value);
        for(let j = 1; j <= numEpisodes; j++){
          const episodeInput = document.createElement('input');
          episodeInput.type = "text";
          episodeInput.placeholder = `رابط الحلقة ${j}`;
          episodeInput.className = "episodeLink";
          episodesContainer.appendChild(episodeInput);
        }
      });
    }
  });
  document.getElementById('submitAddSeries').addEventListener('click', () => {
    let selectedArtists = [];
    document.querySelectorAll('#seriesStarList .selected-artist').forEach(item => {
      selectedArtists.push(item.dataset.artist);
    });
    const seasonsInputs = document.querySelectorAll('.episodesCount');
    let seasons = {};
    seasonsInputs.forEach(input => {
      const seasonNum = input.dataset.season;
      const episodesContainer = document.getElementById('episodesLinks_' + seasonNum);
      let episodeLinks = [];
      episodesContainer.querySelectorAll('.episodeLink').forEach(ep => {
        episodeLinks.push(ep.value);
      });
      seasons[seasonNum] = { numberOfEpisodes: input.value, links: episodeLinks };
    });
    const seriesData = {
      name: document.getElementById('seriesName').value,
      releaseDate: document.getElementById('seriesReleaseDate').value,
      story: document.getElementById('seriesStory').value,
      section: document.getElementById('seriesSectionSelect').value,
      stars: selectedArtists,
      image: document.getElementById('seriesImage').value,
      seasons: seasons,
      rating: document.getElementById('seriesRating').value
    };
    fetch('/addSeries', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(seriesData)
    })
    .then(response => response.json())
    .then(data => {
      if(data.success){
        alert("تم إضافة المسلسل");
        document.getElementById('modalAddSeries').style.display = 'none';
        clearModalFields('modalAddSeries');
        if(currentCategory === "series") loadSeriesContent();
      } else {
        alert(data.message);
      }
    })
    .catch(err => {
      console.error(err);
      alert("حدث خطأ");
    });
  });
  
  /********* وظيفة إكمال الفنانين (الاقتراحات) *********/
  function setupArtistAutocomplete(inputId, suggestionDivId, selectedDivId) {
    const inputElem = document.getElementById(inputId);
    const suggestionDiv = document.getElementById(suggestionDivId);
    const selectedDiv = document.getElementById(selectedDivId);
    let selectedArtists = [];
    
    inputElem.addEventListener('keyup', function() {
      let query = inputElem.value.trim().toLowerCase();
      suggestionDiv.innerHTML = "";
      if(query.length === 0) return;
      let suggestions = allArtists.filter(artist => artist.name.toLowerCase().startsWith(query));
      suggestions.forEach(artist => {
        if(selectedArtists.includes(artist.name)) return;
        let suggestionItem = document.createElement('div');
        suggestionItem.className = "suggestion-item";
        suggestionItem.innerText = artist.name;
        suggestionItem.addEventListener('click', function() {
          if(selectedArtists.length < 7 && !selectedArtists.includes(artist.name)) {
            selectedArtists.push(artist.name);
            let selectedItem = document.createElement('span');
            selectedItem.className = "selected-artist";
            selectedItem.dataset.artist = artist.name;
            selectedItem.innerHTML = artist.name + ' <span class="remove-artist">×</span>';
            selectedItem.querySelector('.remove-artist').addEventListener('click', function(e) {
              e.stopPropagation();
              selectedDiv.removeChild(selectedItem);
              selectedArtists = selectedArtists.filter(a => a !== artist.name);
            });
            selectedDiv.appendChild(selectedItem);
          }
          inputElem.value = "";
          suggestionDiv.innerHTML = "";
        });
        suggestionDiv.appendChild(suggestionItem);
      });
    });
  }
  
  setupArtistAutocomplete('movieStars', 'movieStarSuggestions', 'movieStarList');
  setupArtistAutocomplete('seriesStars', 'seriesStarSuggestions', 'seriesStarList');
  
  // ربط أزرار الشريط الجانبي
  document.querySelectorAll('.nav-button').forEach(button => {
    button.addEventListener('click', function(){
      const category = this.getAttribute('data-category');
      if(category === "home") loadHomeContent();
      else if(category === "movies") loadMoviesContent();
      else if(category === "series") loadSeriesContent();
    });
  });
  
  // بدء التشغيل
  loadHomeContent();
});
