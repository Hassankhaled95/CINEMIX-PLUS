const express = require('express');
const fs = require('fs');
const path = require('path');
const session = require('express-session');

const app = express();
const PORT = 3000;

// إعداد الميدلوير للتعامل مع JSON
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// إعداد الجلسات
app.use(session({
  secret: 'secretKey123',
  resave: false,
  saveUninitialized: true
}));

// middleware لحماية صفحة index.html
app.use((req, res, next) => {
  if (req.path === '/index.html' && !req.session.user) {
    return res.redirect('/login.html');
  }
  next();
});

// تقديم الملفات الثابتة من نفس المجلد
app.use(express.static(path.join(__dirname)));

// دوال مساعدة للتعامل مع ملفات JSON
function readJSON(filePath) {
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify([]));
  }
  const data = fs.readFileSync(filePath);
  try {
    return JSON.parse(data);
  } catch (err) {
    return [];
  }
}

function writeJSON(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

// --- بيانات المستخدمين --- //
const usersFile = path.join(__dirname, 'users.json');
function readUsers() {
  if (!fs.existsSync(usersFile)) {
    fs.writeFileSync(usersFile, JSON.stringify([]));
  }
  const data = fs.readFileSync(usersFile);
  return JSON.parse(data);
}
function writeUsers(users) {
  fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
}

// نقطة نهاية لتسجيل حساب جديد
app.post('/signup', (req, res) => {
  const { firstName, lastName, username, email, password, birthDate, gender } = req.body;
  if (!firstName || !lastName || !username || !email || !password || !birthDate || !gender) {
    return res.json({ success: false, message: 'جميع الحقول مطلوبة' });
  }
  let users = readUsers();
  if (users.find(user => user.username === username)) {
    return res.json({ success: false, message: 'اسم المستخدم موجود بالفعل' });
  }
  const newUser = { firstName, lastName, username, email, password, birthDate, gender };
  users.push(newUser);
  writeUsers(users);
  return res.json({ success: true });
});

// نقطة نهاية لتسجيل الدخول
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  let users = readUsers();
  const user = users.find(user => user.username === username && user.password === password);
  if (user) {
    req.session.user = user;
    return res.json({ success: true });
  } else {
    return res.json({ success: false, message: 'بيانات الدخول غير صحيحة' });
  }
});

// نقطة نهاية لإرجاع اسم المستخدم الحالي من الجلسة
app.get('/sessionUser', (req, res) => {
  if (req.session.user) {
    res.json({ username: req.session.user.username });
  } else {
    res.json({});
  }
});

// --- التعامل مع الأقسام --- //
app.post('/addSection', (req, res) => {
  const { category, sectionName } = req.body;
  if (!category || !sectionName) {
    return res.json({ success: false, message: "بيانات غير كافية" });
  }
  let fileName = "";
  if (category === "home") {
    fileName = 'homeSections.json';
  } else if (category === "movies") {
    fileName = 'moviesSections.json';
  } else if (category === "series") {
    fileName = 'seriesSections.json';
  } else {
    return res.json({ success: false, message: "فئة غير معروفة" });
  }
  const filePath = path.join(__dirname, fileName);
  let sections = readJSON(filePath);
  if (sections.includes(sectionName)) {
    return res.json({ success: false, message: "القسم موجود بالفعل" });
  }
  sections.push(sectionName);
  writeJSON(filePath, sections);
  return res.json({ success: true });
});

app.get('/getSections', (req, res) => {
  const category = req.query.category;
  let fileName = "";
  if (category === "home") {
    fileName = 'homeSections.json';
  } else if (category === "movies") {
    fileName = 'moviesSections.json';
  } else if (category === "series") {
    fileName = 'seriesSections.json';
  } else {
    return res.json([]);
  }
  const filePath = path.join(__dirname, fileName);
  const sections = readJSON(filePath);
  res.json(sections);
});

// --- إضافة فنانين --- //
app.post('/addArtist', (req, res) => {
  const { name, image, nationality } = req.body;
  if (!name || !image || !nationality) {
    return res.json({ success: false, message: "بيانات غير كافية" });
  }
  const filePath = path.join(__dirname, 'artists.json');
  let artists = readJSON(filePath);
  if (artists.find(artist => artist.name === name)) {
    return res.json({ success: false, message: "الفنان موجود بالفعل" });
  }
  artists.push({ name, image, nationality });
  writeJSON(filePath, artists);
  return res.json({ success: true });
});

// --- إضافة فيلم --- //
app.post('/addMovie', (req, res) => {
  const movie = req.body;
  if (!movie.name || !movie.releaseDate || !movie.section) {
    return res.json({ success: false, message: "بيانات غير كافية" });
  }
  const filePath = path.join(__dirname, 'movies.json');
  let movies = readJSON(filePath);
  movies.push(movie);
  writeJSON(filePath, movies);
  return res.json({ success: true });
});

// --- إضافة مسلسل --- //
app.post('/addSeries', (req, res) => {
  const series = req.body;
  if (!series.name || !series.releaseDate || !series.section) {
    return res.json({ success: false, message: "بيانات غير كافية" });
  }
  const filePath = path.join(__dirname, 'series.json');
  let seriesList = readJSON(filePath);
  seriesList.push(series);
  writeJSON(filePath, seriesList);
  return res.json({ success: true });
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
